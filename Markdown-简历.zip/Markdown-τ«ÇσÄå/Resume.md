 <center>
     <h1>许诚成</h1>
     <div>
         <span>
             <img src="assets/phone-solid.svg" width="18px">
             18117944167
         </span>
         ·
         <span>
             <img src="assets/envelope-solid.svg" width="18px">
             xufongnian@gmail.com
         </span><!--
         ·
         <span>
             <img src="assets/github-brands.svg" width="18px">
             <a href="https://github.com/CyC2018">CyC2018</a>
         </span>
         ·
         <span>
             <img src="assets/rss-solid.svg" width="18px">
             <a href="#">My Blog</a>
         </span>-->
     </div>
 </center>


 ## <img src="assets/info-circle-solid.svg" width="30px"> 个人信息 

 - 男，1995 年出生
 - 求职意向：golang 研发工程师
 - 工作经验：4 年
 - 期望薪资：13k

## <img src="assets/graduation-cap-solid.svg" width="30px"> 教育经历

- 本科，西华师范大学，计算机信息管理，2013.8~2017.6

## <img src="assets/briefcase-solid.svg" width="30px"> 工作经历

- **时间：**

   2016.10 – 2018.3
   
- **所在公司：**

   海地云信息技术有限公司
   
- **担任职位：**

   Python开发、Golang开发
   
- **主要职责：**

   1、熟悉了解公司旧业务逻辑与开发思路并整理优化现有代码

   2、学习Go语法与机制

   3、对公司旧业务代码重新架构并迁移至Go（原为Python）

   4、参与新架构的服务端设计与通讯协议制定

   5、服务端负载优化，保证线上服务稳定运行

   **-------------------------------------------------------------------------------**

+ **时间：**

  2018.5 — 2020.5

+ **所在公司：**

  盛裕宏科技有限公司

+ **担任职位：**

  Golang开发

+ **主要职责：**

  1、独立负责本项目小组游戏服务端的设计开发和维护工作

  2、当前游戏服务端业务设计与通讯协议设定

  3、游戏服务端业务代码实现，客户端协议对接

  4、当前所负责的游戏运行性能和架构优化

  5、日常业务服务端代码的修复与改进

  **-------------------------------------------------------------------------------**

- **时间：**

  2020.6 — 至今

+ **所在公司：**

  中软国际科技服务有限公司 （外派到腾讯）

+ **担任职位：**

  Golang开发

+ **主要职责：**

  1、主要负责辅助开发与设计王者营地用户模块业务

  2、设计并开发附近的人业务模块（优化大数据量Key）

  3、迁移公共用户数据具像化业务到Go

  4、用户模块整体cgi业务维护与开发

  5、勋章业务用户方面业务开发

  6、开发设计新用户认证体系与对接兼容老认证业务

## <img src="assets/project-diagram-solid.svg" width="30px"> 项目经历

- **XXXX 项目**

  *使用到的技术*

  使用一两句话描述项目的主要功能，然后介绍自己在项目中的角色，解决了什么问题，使用什么方式解决，比别人的方法相比有什么优势（尽量用数据来说明）。

## <img src="assets/tools-solid.svg" width="30px"> 技能清单

- ★★★ Golang
- ★★☆ C++、Python
- ★★★ MySQL
- ★★★ Redis
- ★★☆ Spring
- ★☆☆ RabbitMQ、ZooKeeper
- ★★☆ JavaScript